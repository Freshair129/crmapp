# Lead Source Analysis Report (Feb 1-22, 2026)

สรุปที่มาของ Total Leads (227 Leads) ในช่วงวันที่ 1-22 กุมภาพันธ์ โดยแยกตามแคมเปญโฆษณา

## 🔝 Top Lead Sources

| Campaign Name | Leads | Spend (฿) | Cost Per Lead (฿) |
| :--- | :---: | :---: | :---: |
| **ซูชิสร้างอาชีพ 4900** | **61** | ฿3,461 | ฿56.74 |
| **Dimsum Clip 2** | **29** | ฿1,843 | ฿63.54 |
| **Basicskill + Basic JPN** | **27** | ฿3,389 | ฿125.53 |
| **Package ต่างประเทศ** | **18** | ฿2,624 | ฿145.79 |
| **Shabu New** | **13** | ฿708 | ฿54.45 |
| **Food Stylist 3** | **11** | ฿913 | ฿82.97 |
| **รวม 3 Package** (Chef Training) | **11** | ฿1,194 | ฿108.55 |
| &nbsp;&nbsp;&nbsp;• *Intensive Sushi* | - | - | - |
| &nbsp;&nbsp;&nbsp;• *Pro Ramen* | - | - | - |
| &nbsp;&nbsp;&nbsp;• *Basic Japanese / Specialist* | - | - | - |

## 📊 Other Sources

| Campaign Name | Leads | Cost Per Lead (฿) |
| :--- | :---: | :---: |
| Dimsum Clip | 7 | ฿83.27 |
| chinese mongkol | 6 | ฿108.45 |
| Full Course Kao | 6 | ฿153.06 |
| Ramen | 5 | ฿129.65 |
| Shabu Walter | 5 | ฿85.60 |
| Kids Camp SS2 | 5 | ฿176.65 |
| Camp12 | 6 | ฿153.64 |
| ขายขนมมงคล | 4 | ฿115.29 |
| Korea Multi | 4 | ฿369.05 |
| Package Sushi | 3 | ฿206.31 |
| Dinner 2 | 2 | ฿56.52 |
| Food Stylist 4 | 1 | - |
| bundle Jan | 1 | - |
| Camp12 (Subset) | 1 | - |

## 💡 Key Findings

- **ประสิทธิภาพสูงสุด (Lowest CPL)**: แคมเปญ **"Shabu New"** (฿54.45) และ **"ซูชิสร้างอาชีพ 4900"** (฿56.74) เป็นกลุ่มที่ทำราคาต่อ Lead ได้ถูกที่สุด
- **ปริมาณสูงสุด (Highest Volume)**: **"ซูชิสร้างอาชีพ 4900"** เป็นแหล่งที่มาหลักของ Lead ในเดือนนี้ (27% ของทั้งหมด)
- **High Intent Sources**: ถึงแม้ **"Basicskill + Basic JPN"** จะมี CPL สูงกว่า (฿125) แต่เป็นกลุ่มที่สร้างรายได้จริง (฿17,000) ในช่วงเวลาที่ผ่านมา

---
*Report Generated: 2026-02-24*
