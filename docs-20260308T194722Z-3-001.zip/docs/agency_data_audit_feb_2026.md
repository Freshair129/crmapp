# Agency Data Audit Report (Feb 1-22, 2026)

รายงานการตรวจสอบความสอดคล้องของข้อมูลระหว่างตาราง Marketing Actual ของ Agency เทียบกับระบบภายใน (Facebook Ads Sync)

## 📊 Comparison Summary (Facebook Only)

| Category | Agency Leads | System Leads | Agency Revenue | System Revenue | Match Status |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Japanese Course** | 49 | 50 | ฿76,600 | ฿17,000 | ⚠️ Revenue Gap |
| **Special Course** | 46 | 48 | ฿9,900 | ฿0* | ⚠️ Revenue Gap |
| **Full Course** | 7 | 6 | ฿0 | ฿0 | ✅ Leads Match |
| **Package** | 69 | 32* | ฿34,000 | ฿9,800 | ⚠️ Gap Found |
| **ขนมมงคล** | 5 | 10 | ฿13,500 | ฿13,500 | 💎 **Perfect Match** |

*\*ข้อมูลระบบภายในอาจมีการแยกย่อยตามชื่อ Ad ที่ต่างกัน รายละเอียดในตารางนี้เป็นการจัดกลุ่มเพื่อให้เทียบกับตาราง Agency ได้ง่ายขึ้น*

## 💡 Analysis & Findings

### 1. Lead Consistency (High)
จำนวน Leads ในกลุ่มสินค้าหลัก (Japanese & Special Course) มีความใกล้เคียงกันผิดพลาดไม่เกิน 2-4% แสดงให้เห็นว่าการนับ Conversion ของทั้งสองฝั่งใช้ฐานข้อมูลชุดเดียวกัน

### 2. Revenue Discrepancy (Sales Reporting Gap)
- **ขนมมงคล (Perfect Match)**: เป็นกลุ่มเดียวที่ข้อมูลตรงกัน 100% แสดงว่าระบบ Tracking พื้นฐานทำงานได้ถูกต้อง
- **Japanese & Package Gap**: Agency บันทึกยอดขายสูงกว่าระบบ Facebook ของเราอย่างนัยสำคัญ
    - **สาเหตุที่ยืนยันแล้ว**: Agent มักจะลากลูกค้าจาก Facebook ไปจบการขายใน **Line AO** และแจ้งยอดเพียงอย่างเดียว โดยไม่ได้กลับมาบันทึก Offline Conversion หรือแก้ไขข้อมูลในระบบ Facebook ทำให้ยอดขายจริงไม่ไหลกลับเข้าสู่ Facebook Pixel
    - **ผลกระทบ**: ข้อมูลรายได้ใน Facebook Marketing API จึงต่ำกว่าความเป็นจริง (Under-reporting) ในขณะที่ตารางของ Agency อาจรวมยอดจาก Line AO เข้าไปด้วยแล้ว

## 📝 Recommendations
- ควรตรวจสอบวิธีการบันทึกยอดขายของ Agency ในคอร์ส Japanese ว่ามีการนับรวมยอดจากช่องทางใดบ้าง (เช่น ปิดการขายใน Line แต่อ้างอิงกลับมาที่ Facebook Ads)
- ระบบ CRM ควรเริ่มมีการบันทึก Order เข้ามาจริงเพื่อใช้เป็น "Source of Truth" ชุดที่สามในการเปรียบเทียบ

---
*Generated: 2026-02-24*
*Comparison Period: Feb 1-22, 2026*
